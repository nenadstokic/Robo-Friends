export const robots = [
  {
    id: 1,
    name: 'Nenad Stokic',
    username: 'Nesa',
    email: 'nenad@gmail.com'
  },
  {
    id: 2,
    name: 'Ljiljana Zlatkovic Stokic',
    username: 'Ljika',
    email: 'ljiljana@gmail.com'
  },
  {
    id: 3,
    name: 'Bogdan Stokic',
    username: 'Boki',
    email: 'bogdan@gmail.com'
  },
  {
    id: 4,
    name: 'Dmitrije Stokic',
    username: 'Dima',
    email: 'dimitrije@gmail.com'
  },
  {
    id: 5,
    name: 'Sreten Stanojević',
    username: 'Srele',
    email: 'sretenp@gmail.com'
  },
  {
    id: 6,
    name: 'Bojana Stanojević',
    username: 'Bojana',
    email: 'boki@gmail.com'
  },
  {
    id: 7,
    name: 'Lazar Stanojević',
    username: 'Laza',
    email: 'laza@gmail.com'
  },
]
